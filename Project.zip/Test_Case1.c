int fact(int n) {
if(n <= 1)
return 1;
else/* multiline comment 1
2
3
4*/
return n*fact(n-1);
}
void main(void) {
int x;
x = 1;
while@
/
,
while(x <= 15) {
printf(x);
printf(fact(x));
writeln();
x = x + 1;
}
}