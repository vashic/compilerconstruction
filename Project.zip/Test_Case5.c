func(){
 a = 1;
 b = 1;	
 c = 0;
 d = 0;
 e = a | b
 f = a & c & d |
 g = b || d && e
 print( a+b+c+d)
 print( 100 * 90 - 60 % 7)
print('g')
}

int main(){
 func()
]
