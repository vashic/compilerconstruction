void main(){
boolean fact1 = true
boolean fact 2 = false
/*checking boolean operators*/
boolean fact 3 = fact1 && fact2
boolean fact 4 = fact1 || fact2
print(fact3, fact 4,'\n', '\\' ,'','\8')
ch = " mutliline string
secondline"
return
}