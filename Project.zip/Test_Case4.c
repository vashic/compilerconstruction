/*insert comments here*/

int main(){
a=10;
b=10000;
	c = 50;
if	(a>=b && b<9)
	print ("A")
else if (b==c && c!=a) {
	print ("C")
}
else if (c > 100)
print b :
}