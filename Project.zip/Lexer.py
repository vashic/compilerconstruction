#!/usr/bin/env python3 

#CODE BY :
#Vashi Chaudhary        :2018A7PS0243H
#Akash Srivastava       :2018A7PS0241H
#Shreya Gupta           :2018A7PS0256H
#Tej Shirish Sukhatme   :2018A7SP0020H

from __future__ import print_function
import sys

#Tokens in our programming language
Token_List = ["End_of_file", "Multiplication_Operator", "Division_Operator", "Modulo_Operator", "Addition_Operator", "Subtraction_Operator",
    "NOT_Operator", "LessThan_Operator", "LessThanEqual_Operator", "GreaterThan_Operator", "GreaterThanEqual_Operator",
    "Equal_Operator", "NotEqual_Operator", "Assignment_Operator", "AND_Operator", "OR_Operator", "IF_Keyword",
    "Else_Keyword", "While_Keyword", "Int_Keyword","Print_Keyword", "Left_Parenthesis","Right_Parenthesis", "Left_Brace", "Right_Brace",
     "Semicolon", "Comma", "Identifier","Integer", "String","Return_Keyword","Void_Keyword","True_Keyword","False_Keyword","Boolean_Keyword","Main_Keyword"]

#Token Names
EndOfFile_token, MUL_token, DIV_token, MODULO_token, ADD_token, SUB_token, NOT_token, LESS_token, LEQ_token, GTR_token, GEQ_token, EQ_token, NEQ_token, ASSIGNMENT_token, AND_token, OR_token, IF_token, ELSE_token, WHILE_token, INT_token, PRINT_token, LEFTPAREN_token, RIGHTPAREN_token, LEFTBRACE_token, RIGHTBRACE_token, SEMICOLON_token, COMMA_token, IDENTIFIER_token, INTEGER_token, STRING_token, Return_token, Void_token, TRUE_token, FALSE_token, BOOLEAN_token, Main_Token = range(36)

#list of keywords 
Keyword_list = {'main': Main_Token,'boolean' : BOOLEAN_token,'true' : TRUE_token, 'false' : FALSE_token , 'void' : Void_token,'return': Return_token, 'if': IF_token, 'else': ELSE_token, 'print': PRINT_token, 'while': WHILE_token, 'int' : INT_token}

#list of symbols
Symbols_list = { '{': LEFTBRACE_token, '}': RIGHTBRACE_token, '(': LEFTPAREN_token, ')': RIGHTPAREN_token, '+': ADD_token, '-': SUB_token,
    '*': MUL_token, '%': MODULO_token, ';': SEMICOLON_token, ',': COMMA_token }

#some variables
scanned_char = " "    
col_num = 0
line_num = 1
input_file = None
Comment_Code = 50
newline_code = 51
Backslash_code = 52 
Character_literal_code = 53

# classification functions for tokens

#gets the next character abd increments the file pointer
def get_next_char():
    global scanned_char, col_num, line_num
    col_num += 1
    scanned_char = input_file.read(1)
    if scanned_char == '\n':
        col_num = 0
        line_num += 1
    return scanned_char

# To print error messages 
def print_error(line, col, error_message):
    print("ERROR : Line %d column %d %s " % (line, col, error_message))
    #exit(1)
    get_next_char()    
    token_and_output()
    exit(1) 

#check if the token is a string, also checks for certain errors
def check_string(start, current_line, current_column):
    text = ""
    while get_next_char() != start:
        if len(scanned_char) == 0:
            print_error(current_line, current_column, "EOF while scanning string literal")
            
        if scanned_char == '\n':
            print_error(current_line, current_column, "EOL while scanning string literal")
            
        text += scanned_char
 
    get_next_char()
    return STRING_token, current_line, current_column, text

# Checks if token is an integer or a valid identifier
# Gives error for invalid identifiers 
def check_integer_or_identifier(current_line, current_column):
    is_number = True
    text = ""
 
    while scanned_char.isalnum() or scanned_char == '_':
        text += scanned_char
        if not scanned_char.isdigit():
            is_number = False
        get_next_char()
 
    if len(text) == 0:
        print_error(current_line, current_column, "check_integer_or_identifier: unrecognized character: (%d) '%c'" % (ord(scanned_char), scanned_char))
        
        
    if text[0].isdigit():
    
        if not is_number:
            print_error(current_line, current_column, "invalid number: %s" % (text))
            
        n = int(text)
        return INTEGER_token, current_line, current_column, n
 
    if text in Keyword_list:
        return Keyword_list[text], current_line, current_column,text
 
    return IDENTIFIER_token, current_line, current_column, text

#Checks if a comment or the division operator is the token
# checks for mutiline comments  or when file ends in the comment 
def check_divison_or_comment(current_line, current_column):
    prev_line= current_line
    prev_char = scanned_char
    if get_next_char() != '*':
        return DIV_token, current_line, current_column, prev_char
    
    get_next_char()
    while True:
        if scanned_char == '*':
            if get_next_char() == '/':
                get_next_char()
                next_line=line_num
                print("Token %d, Comment Encountered */....*/ , lines %d to %d" % (Comment_Code,prev_line,next_line-1))
                return get_token()
        elif len(scanned_char) == 0:
            print_error(current_line, current_column, "EOF in comment")           
        else:
            get_next_char()

# Checks for operators such as leq, le, geq, ge, eq, neq
def check_special_symbols(first_option, first_option_token, second_option_token, second_option, current_line, current_column):
    prev_char = scanned_char
    if get_next_char() == first_option:
        get_next_char()
        val= ""    
        val += prev_char
        val += first_option
        return first_option_token, current_line, current_column,val
 
    if second_option_token == EndOfFile_token:
        print_error(current_line, current_column, "check_special_symbols: unrecognized character: (%d) '%c'" % (ord(prev_char), prev_char))
    
    val= ""    
    val += prev_char
    val += second_option
    return second_option_token, current_line, current_column, val
 
# Checks escape sequences and characters 
def check_character_literals(current_line, current_column):
    val = get_next_char()              
    if scanned_char == '\'':
        print_error(current_line, current_column, "empty character constant")
        
    elif scanned_char == '\\':
        get_next_char()
        if scanned_char == 'n':
            val = "\\n"
        elif scanned_char == '\\':
            val = "\\"
        else:
            prev_char=scanned_char
            get_next_char()
            print_error(current_line, current_column, "unknown escape sequence '\\%c'" % (prev_char))
    

    if get_next_char() != '\'':
        print_error(current_line, current_column, "multi-character constant")
        
    get_next_char()
    return "CharacterLiteral_Token", current_line, current_column, val

def get_token():
    while scanned_char.isspace():
        get_next_char()
 
    current_line = line_num
    current_column  = col_num
 
    if len(scanned_char) == 0:    return EndOfFile_token, current_line, current_column,''
    elif scanned_char == '/':     return check_divison_or_comment(current_line, current_column)
    elif scanned_char == '\'':    return check_character_literals(current_line, current_column)
    elif scanned_char == '<':     return check_special_symbols('=', LEQ_token, LESS_token, '',   current_line, current_column)
    elif scanned_char == '>':     return check_special_symbols('=', GEQ_token, GTR_token, '',   current_line, current_column)
    elif scanned_char == '=':     return check_special_symbols('=', EQ_token,  ASSIGNMENT_token,'', current_line, current_column)
    elif scanned_char == '!':     return check_special_symbols('=', NEQ_token, NOT_token, '',   current_line, current_column)
    elif scanned_char == '&':     return check_special_symbols('&', AND_token, EndOfFile_token,'',    current_line, current_column)
    elif scanned_char == '|':     return check_special_symbols('|', OR_token,  EndOfFile_token,'' ,  current_line, current_column)
    elif scanned_char == '"':     return check_string(scanned_char, current_line, current_column)
    elif scanned_char in Symbols_list:
        sym = Symbols_list[scanned_char]
        prev_char = scanned_char
        get_next_char()
        return sym, current_line, current_column, prev_char
    else: return check_integer_or_identifier(current_line, current_column)
 
def token_and_output(): 
    while True:
        #this section includes the following :
        #output for check_special_symbols : second_option_token, current_line, current_column, val
        #output for stringlit : STRING_token, current_line, current_column, text
        #output for characterliterals : return "ESCAPE_SEQUENCE", current_line, current_column, val
        #output for div : DIV_token, current_line, current_column, prev_char(/)
        #output for sym : sym, current_line, current_column, prev_char
        #output for identifer : IDENTIFIER_token, current_line, current_column, text
        #output for comment : taken care of

        t = get_token()
        tok  = t[0]
        line = t[1]
        col  = t[2]
        if(tok=='CharacterLiteral_Token'):
            if t[3]=="\\n" :
                tok="Newline_Character"
                code= 51
            elif t[3]=="\\" :
                tok = "Backslash_Character"
                code = 52
            else :
                code = 53
            print("Token %d, %-14s '" % (code, tok),end='')
        else :        
            print("Token %d, %-14s '" % (tok, Token_List[tok]),end='')
        if tok == INTEGER_token:  print("%d" % (t[3]),end='')
        elif tok == IDENTIFIER_token or tok=='CharacterLiteral_Token':  print("%s" %   (t[3]),end='')
        elif tok == STRING_token: print('"%s"' % (t[3]),end='')
        else:
            print("%s" % (t[3]),end='')
        print("', line number %d" % (line))
        if tok == EndOfFile_token:      break

#main driver
input_file = sys.stdin
if len(sys.argv) > 1:
    try:
        input_file = open(sys.argv[1], "r", 4096)
    except IOError as e:
        print_error(0, 0, "Can't open %s" % sys.argv[1])
        exit(1)     
token_and_output()


#end of program    