/*multiline comment 1
2
3*/



int a = 0123:
int h@i;
string name = "abc;
while(a>0):
	name = name + 1
	h@i = a
	a = a-1

return h@i/*
EOF

	

